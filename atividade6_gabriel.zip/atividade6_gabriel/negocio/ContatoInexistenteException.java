package atividade6_gabriel.negocio;

public class ContatoInexistenteException extends Exception{
    
    public ContatoInexistenteException(String mensagem){
        super(mensagem);
    }

}

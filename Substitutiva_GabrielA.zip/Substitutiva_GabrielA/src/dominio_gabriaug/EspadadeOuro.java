package dominio_gabriaug;

public class EspadadeOuro extends Espada{
    public EspadadeOuro() {
        super("Espada de Ouro", 50, 'O');
    }
}

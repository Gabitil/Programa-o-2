package dominio_gabriaug;

public class EspadadeMadeira extends Espada{
    public EspadadeMadeira(){
        super("Espada de Madeira", 5, 'M');
    }
}

package dominio_gabriaug;

public class EspadadeAluminio extends Espada {

    public EspadadeAluminio() {
        super("Espada de Aluminio", 10, 'A');
    }
    
}

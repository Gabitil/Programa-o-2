package dominio_gabriaug;

public class EspadadePlatina extends Espada{
    public EspadadePlatina(){
        super("Espada de Platina", 30, 'P');
    }
}

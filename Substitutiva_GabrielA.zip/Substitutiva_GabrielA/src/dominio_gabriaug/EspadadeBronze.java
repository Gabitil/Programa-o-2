package dominio_gabriaug;

public class EspadadeBronze extends Espada{
    public EspadadeBronze(){
        super("Espada de Bronze", 40, 'B');
    }
}

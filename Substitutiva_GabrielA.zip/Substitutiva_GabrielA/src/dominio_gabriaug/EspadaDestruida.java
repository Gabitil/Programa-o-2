package dominio_gabriaug;

public class EspadaDestruida extends Espada{
    
        public EspadaDestruida() {
            super("Espada Destruida", 0, 'D');
        }
}

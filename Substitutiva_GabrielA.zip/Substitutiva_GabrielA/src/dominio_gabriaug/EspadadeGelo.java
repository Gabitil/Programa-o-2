package dominio_gabriaug;

public class EspadadeGelo extends Espada{
    public EspadadeGelo() {
        super("Espada de Gelo", 20, 'G');
    }
}

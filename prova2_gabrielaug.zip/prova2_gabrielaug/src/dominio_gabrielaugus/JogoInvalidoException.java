package dominio_gabrielaugus;

public class JogoInvalidoException extends Exception {
    public JogoInvalidoException(String mensagem) {
        super(mensagem);
    }
}

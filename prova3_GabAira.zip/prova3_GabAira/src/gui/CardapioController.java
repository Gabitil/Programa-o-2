package gui;

import dominio.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

public class CardapioController {
    private Cardapio cardapio = new Cardapio();
    private ToggleGroup grupoBotoes = new ToggleGroup();
    @FXML
    private TextField tfVCalorico;

    @FXML
    private Button btIncluir;

    @FXML
    private Button btConsultar;

    @FXML
    private RadioButton rbJantar;

    @FXML
    private RadioButton rbCeia;

    @FXML
    private ComboBox<String> cbDSemana;

    @FXML
    private TextField tfDescricao;

    @FXML
    private RadioButton rbAlmoco;

    @FXML
    private Button btLimpar;

    @FXML
    private RadioButton rbLancheT;

    @FXML
    private Button btAlterar;

    @FXML
    private Button btRemover;

    @FXML
    private RadioButton rbLancheM;

    @FXML
    private RadioButton rbCafeM;

    @FXML
    void handleBotões(ActionEvent event) {
        String botao = ((Button)event.getSource()).getText();
        switch(botao){
            case "Incluir":
                try {
                    String temporario= grupoBotoes.getSelectedToggle().toString();
                    cardapio.incluir(tfDescricao.getText(), Double.parseDouble(tfVCalorico.getText()), cbDSemana.getValue(),temporario)  ;
                    
                } catch (DupilicadeException e) {
                    System.out.println(e.getMessage());
                }
                break;
            case "Consultar":

                Refeicao refeicaoCnsulta = cardapio.consultar(tfDescricao.getText());
                if (refeicaoCnsulta != null){
                    tfVCalorico.setText(String.valueOf(refeicaoCnsulta.getvCalorico()));
                }

                break;
            case "Alterar":
                cardapio.alterar(tfDescricao.getText(), Double.parseDouble(tfVCalorico.getText()));
                break;
            case "Remover":
                cardapio.excluir(tfDescricao.getText());
                break;
            case "Limpar":
                tfDescricao.setText("");
                tfVCalorico.setText("");
                break;

        }
       

    }


    @FXML
    public void initialize(){
        cbDSemana.getItems().addAll("Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo");

       
        rbAlmoco.setToggleGroup(grupoBotoes);
        rbJantar.setToggleGroup(grupoBotoes);
        rbCeia.setToggleGroup(grupoBotoes);
        rbCafeM.setToggleGroup(grupoBotoes);
        rbLancheM.setToggleGroup(grupoBotoes);
        rbLancheT.setToggleGroup(grupoBotoes);

    }
}
